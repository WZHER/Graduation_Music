import App from './App'
import uView from './uni_modules/vk-uview-ui';
import Store from './store/index.js'

// #ifdef VUE3
import { createSSRApp } from 'vue'
export function createApp() {
  const app = createSSRApp(App)
  
  app.use(uView).use(Store)
  
  return {
    app
  }
}
