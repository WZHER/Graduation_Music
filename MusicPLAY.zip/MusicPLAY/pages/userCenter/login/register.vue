<template>
	<view class="alllogin">
						<u-gap height="100" bg-color="white"></u-gap>
		<image src="../../static/vip.png" style="height: 15%;"></image>
		<u-gap height="30" bg-color="white"></u-gap>
		<text style="font-size: 30px; color\:#E60026; " >注册就送黑胶VIP</text>
		<u-gap height="50" bg-color="white"></u-gap>
		<form action="" class="login">
			
			<view class="username">
				<u-field v-model="mobile" label="" placeholder="请填写用户名" icon="account-fill" clearable="false">
				</u-field>
			</view>
			<view class="password" style="margin-top: 5%;">
				<u-field v-model="mobile" label="" placeholder="请输入密码" icon="lock-fill" clearable="false">
				</u-field>
			</view>
			<view class="password" style="margin-top: 5%;">
				<u-field v-model="mobile" label="" placeholder="请重复密码" icon="lock-fill" clearable="false">
				</u-field>
			</view>
			<view class="" style="margin-top: 10%; margin-bottom: 10%;">
				<text style="margin-right: 25%; " @click="log">已经有账户？去登录</text>
			</view>
			<view class="">
				<u-button @click="reg" style="border: none; color: #4688f4;">注册</u-button>
			</view>
		</form>
	</view>
</template>

<script setup>
	import {
		ref
	} from 'vue'; // 导入ref函数

	import {
		useRouter
	} from 'vue-router'; // 导入useRouter函数
	const log = () => {
		uni.navigateTo({
			url: "/pages/userCenter/login/login"
		});
	}; // 定义方法
	const reg = () => {
		uni.switchTab({
			url: '/pages/userCenter/userCenter'
		});
	}; // 定义方法
</script>

<style>
	.alllogin {
		display: flex;
		flex-direction: column;
		align-items: center;
		/* justify-content: center; */
		height: 100vh;

	}

	.login {
		margin-top: 2%;

	}
/* 
	.login image {
		margin-left: 38%;
		width: 140rpx;
		height: 140rpx;
		margin: bottom 3rpx;
	} */
</style>