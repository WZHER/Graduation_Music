<template>
	<view class="alllogin">
		<form action="" class="login">

			<image src="../../static/logo.png" mode=""></image>

			<view class="username">
				<u-field v-model="username" label="" placeholder="请填写用户名" icon="account-fill" clearable="false">
				</u-field>
			</view>
			<view class="password" style="margin-top: 5%;">
				<u-field v-model="password" type="password" placeholder="请输入密码" icon="lock-fill" clearable="false">
				</u-field>
			</view>
			<view class="" style="margin-top: 10%; margin-bottom: 10%;">
				<text style="margin-right: 25%; " @click="reg">还没有账号？去注册</text>
				<text>忘记密码?</text>
			</view>
			<view class="">
				<u-button @click="log" style="border: none; color: #4688f4;">登录</u-button>
			</view>

		</form>
	</view>
</template>

<script setup>
	import {
		ref
	} from 'vue'; // 导入ref函数

	import {
		useRouter
	} from 'vue-router'; // 导入useRouter函数
	var username, password;
	const reg = () => {
		uni.navigateTo({
			url: '/pages/userCenter/login/register'
		});
	}; // 定义方法
	const log = () => {
		uni.request({
			url: "http://localhost:3000/user/login",
			method: "POST",
			data: {
				userName: username,
				userPassword: password
			},
			success: (res) => { //如果访问接口成功就会进入success
				console.log("接口调用成功")

				if (res.data.code == "200" && res.data.msg == "success") {
					console.log(res.data)
					uni.showToast({
						title: '登录成功',
						icon: 'success'
					})
					uni.setStorage({
						key: "userInfo",
						data: {
							"user": res.data.data.user,
							"accessToken": res.data.data.accessToken,
						},
					})
				}
				else{
					uni.showToast({
						title: '登陆失败',
						icon: 'none'
					})
				}
				
			},
			fail: () => { //如果访问接口失败就会进入fail
				console.log("调用接口失败")
			}
		})
		uni.reLaunch({
			url: '/pages/userCenter/userCenter'
		});

	}; // 定义方法
</script>

<style>
	.alllogin {
		display: flex;
		flex-direction: column;
		align-items: center;
		/* justify-content: center; */
		height: 100vh;
	}

	.login {
		margin-top: 30%;
	}

	u-field:focus {
		outline: 2px solid #ffaaff
	}

	.login image {
		margin-left: 35%;
		width: 180rpx;
		height: 180rpx;
		margin: bottom 3rpx;
	}
</style>