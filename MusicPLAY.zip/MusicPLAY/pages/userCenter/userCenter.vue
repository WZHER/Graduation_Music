<template>
	<view class="all">
		<view class="geren">


			<view v-if="islogin" style=" margin-top: 30rpx;">
				<view class="" style="display: flex; flex-direction: row;">
					<view>
						<image :src="`http://localhost:3000/${userData.userAvatar}`" style="margin-left: 50%;
					width: 200rpx;
					height: 200rpx;
					margin: bottom 3rpx;
					margin-top: 3rpx;
					border-radius: 20%;" @click="xinxi"></image>
					</view>
					<view class="" style="margin-left: 20%;margin-top: 6%;">
						<text style=" font-size: 20px; margin-bottom: 4%;">

							<text style="font-size: 30px; color: #4f95fc;">{{userData.userName}}</text></text>
						<!-- <u-button type="primary">退出登录</u-button> -->
					</view>
				</view>

				<view class="">
					<u-row gutter="16">
						<u-col span="2">&nbsp;</u-col>
						<u-col span="3">关注</u-col>
						<u-col span="3">粉丝</u-col>
						<u-col span="3">lv.10</u-col>
					</u-row>
					<u-gap height="6" bg-color="#fff3ea"></u-gap>
				</view>
			</view>

			<view v-else style="margin-top: 30rpx;">
				<image src="../../static/人.png" style="margin-left: 35%;
			width: 200rpx;
			height: 200rpx;
			margin: bottom 3rpx;
			margin-top: 3rpx;" mode="" @click="log"></image>
				<view class="" style="margin-left: 28%; font-size: 30px;">
					<text>发现好音乐</text>

				</view>

			</view>
		</view>


		<view class="classfy">
			<u-grid :col="4">
				<u-grid-item>
					<image src="../../static/播放1.png"></image>
					<view class="grid-text">最佳播放</view>
				</u-grid-item>
				<u-grid-item>
					<image src="../../static/本地下载.png" mode=""></image>
					<view class="grid-text">本地</view>
				</u-grid-item>
				<u-grid-item>
					<image src="../../static/云盘.png" mode=""></image>
					<view class="grid-text">云盘</view>
				</u-grid-item>
				<u-grid-item @click="shoucang(userData.userId)">
					<image src="../../static/赞.png" mode=""></image>
					<view class="grid-text">收藏</view>
				</u-grid-item>
			</u-grid>
		</view>
		<view class="">
			<u-gap height="16" bg-color="white"></u-gap>
			<text style="font-size: 22px;">音乐品味</text>
			<u-gap height="16" bg-color="white"></u-gap>
			<u-row gutter="16">

				<u-col span="3" style="">
					<image src="../../static/未标题-1.png" style="height: 100rpx; width: 100rpx" alt=""></image>
				</u-col>
				<u-col span="9">
					<text style="font-size: large;">听歌排行</text>
					<u-gap height="6" bg-color="white"></u-gap>
					<text>累计听歌1000首</text>
				</u-col>
			</u-row>
			<u-row gutter="16">
			
				<u-col span="3" style="">
					<image src="../../static/未标题-2.png" style="height: 100rpx; width: 100rpx" alt=""></image>
				</u-col>
				<u-col span="9">
					<text style="font-size: large;">我喜欢的音乐</text>
					<u-gap height="6" bg-color="white"></u-gap>
					<text>34首，播放122次</text>
				</u-col>
			</u-row>
		</view>

		<view class="collapse">
			<u-collapse>
				<u-collapse-item :title="item.head" v-for="(item, index) in itemList" :key="index">
					{{item.body}}
				</u-collapse-item>
			</u-collapse>
		</view>
	</view>
</template>

<script setup>
	import {
		ref
	} from 'vue'
	import {
		onLoad
	} from '@dcloudio/uni-app';



	// 定义积分和是否已签到的响应式数据
	const points = ref(0);
	const hasSignedIn = ref(false);

	// 定义签到方法
	const signIn = () => {
		if (!hasSignedIn.value) {
			points.value += 1; // 积分加一
			hasSignedIn.value = true; // 将 hasSignedIn 设置为 true，签到文本不再显示
		}
	};

	const userData = ref([])
	const islogin = ref(false)
	onLoad(() => {

		uni.getStorage({
			key: "userInfo",
			success: function(res) {
				// console.log(res.data.user);
				userData.value = res.data.user;
				return islogin.value = true
			}
		})
	})
	const xinxi = (res) => {

		uni.getStorage({
			key: "userInfo",
			success: function(res) {
				// 更新响应式数据
				userData.value = res.data.user;
				islogin.value = true; // 假设这是Vue 3的响应式状态
				// 导航到用户中心的收藏页面，注意检查userId是否需要转义或验证
				uni.navigateTo({
					url: '/pages/userCenter/user/user?id=' + res.data.user.userId
				});
			},
			fail: function(err) {
				// 处理失败的情况
				console.error('Failed to get storage', err);
			}
		});
	};
	// 查看个人歌单
	const shoucang = (res) => {
		uni.getStorage({
			key: "userInfo",
			success: function(res) {
				// 更新响应式数据
				userData.value = res.data.user;
				islogin.value = true; // 假设这是Vue 3的响应式状态
				// 导航到用户中心的收藏页面，注意检查userId是否需要转义或验证
				uni.navigateTo({
					url: '/pages/userCenter/userCollect?id=' + res.data.user.userId
				});
			},
			fail: function(err) {
				// 处理失败的情况
				console.error('Failed to get storage', err);
			}
		});
	};
	// console.log(islogin)
	const loginout = () => {
		try {
			uni.removeStorageSync('userInfo');
			return islogin.value = false
			uni.reLaunch()({
				url: '/pages/userCenter/userCenter'
			});
		} catch (err) {
			console.log(err)
		}
	}
	const log = () => {
		uni.navigateTo({
			url: '/pages/userCenter/login/login'
		});
	}; // 定义方法

	const itemList = [{
		head: "我的常听",
		body: "好音乐应该得到欣赏",
		open: true,
		disabled: true
	}, {
		head: "我的积分",
		body: "1.00",
		open: false,
	}, {
		head: "我的客服",
		body: "唐建强：023-13042120321",
		open: false,
	}]
</script>

<style>
	.geren {
		margin-top: 30rpx;
		padding: 3rpx;
		border-top-left-radius: 15px;
		/* 设置左上角的圆角 */
		border-top-right-radius: 15px;
		/* 设置右上角的圆角 */
		border-bottom-right-radius: 15px;
		/* 设置右下角的圆角 */
		border-bottom-left-radius: 15px;
		/* 设置左下角的圆角 */
		background-color: #fff3ea;
	}

	.u-bottom {
		display: flex;
		justify-content: space-around;
		/* align-items: center; */
	}

	.all {
		width: 90%;
		margin-left: 5%;
	}

	.collapse {
		margin-top: 20rpx;

	}

	/* 图标分类 */
	.classfy {
		margin-top: 10rpx;
		margin-right: 10rpx;
		margin-left: 10rpx;
	}

	.classfy image {
		height: 69rpx;
		width: 69rpx
	}
</style>