<template>
	<view class="all">
		<view class="xinxi">
			<image :src="`http://localhost:3000/${Data[0].userAvatar}`" style="margin-left: 37%;
					width: 200rpx;
					height: 200rpx;
					margin: bottom 3rpx;
					margin-top: 40rpx;
					border-radius: 20%;"></image>

		</view>
		<text style="margin-left: 6%; font-size: 40px;">
			{{Data[0].userName}}的喜欢	
		</text>

		<view class="collect" v-for="s in Data[0].favoriteSongs">
	
						<u-gap height="12" bg-color="#e6dee2"></u-gap>
				<u-row gutter="16">
					<!-- <u-col span="3">&nbsp</u-col> -->
					<u-col span="4">
						<image :src="`http://localhost:3000/${s.songCover}`" style="width: 80px; height: 80px;"></image>
					</u-col>
					<u-col span="4">
						<view class="" style="margin-top: 25px;">
						<text style="font-size: 25px">{{s.songTitle}}</text>
						</view>
					</u-col>
					<u-col span="4">
						<view class="" style="margin-top: 25px;" @click="cancle(s.songId)">
							<text style="font-size: 25px;">取消喜欢</text>
						</view>
					</u-col>
					
				</u-row>
				
		
		</view>

	</view>
</template>

<script setup>
	import {
		onMounted,
		ref
	} from "vue";
	import {
		onLoad
	} from '@dcloudio/uni-app';
	const Data = ref([]);
	const cancle = (res)=>{
		console.log(res)
		uni.request({
			url:"http://localhost:3000/favourite/delete?songId="+ JSON.stringify(res),
			method:"DELETE",
			
		})
		
	}
	onLoad((option) => {
		console.log(option)
		
		uni.request({
			url: `http://localhost:3000/user/getFavoriteByUserId?userId=${option.id}`,
			method: "GET",
			success: function(res) {
				if (res.statusCode === 200) {
					// 处理返回的数据
					console.log(res.data);
					Data.value = res.data.data
				} else {
					// 处理请求成功但业务逻辑上的错误
					console.error('请求成功，但状态码不是200');
				}
			},
			fail: function(error) {
				// 处理请求失败的情况
				console.error('请求失败', error);
			}
		});
	});
</script>

<style>
	.all {
		width: 90%;
		margin-left: 5%;
	}

	.all::before {
		z-index: -1;
		content: '';
		position: absolute;
		top: 0;
		left: 0;
		width: 100%;
		height: 10%;
		/* 假设上半部分占页面高度的一半 */
		background-color: #E60026;
	}

	.all::after {
		z-index: -1;
		content: '';
		position: absolute;
		top: 10%;
		/* 从上半部分的底部开始 */
		left: 0;
		width: 100%;
		height: 90%;
		/* 假设下半部分也占页面高度的一半 */
		background-color: #e6dee2;
	}
</style>