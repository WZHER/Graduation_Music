<template>
	<view class="all">
		<view class="xinxi">
			<image :src="`http://localhost:3000/${Data[0].userAvatar}`" style="margin-left: 37%;
					width: 200rpx;
					height: 200rpx;
					margin: bottom 3rpx;
					margin-top: 40rpx;
					border-radius: 20%;"></image>
	
		</view>
		<text style="margin-left: 20%; font-size: 60px;">
			{{Data[0].userName}}
		</text>
		<u-gap height="20" bg-color="#e6dee2"></u-gap>
		<text style="margin-left: 16%; font-size: 20px;">
			个性签名：{{Data[0].signature}}
		</text>
		<u-gap height="20" bg-color="#e6dee2"></u-gap>
		<text style="margin-left: 16%;font-size: 20px;">
			邮箱地址：{{Data[0].mail}}
		</text>
		<u-gap height="20" bg-color="#e6dee2"></u-gap>
<br>
		<text style="margin-left: 16%;font-size: 20px;">
			电话号码：{{Data[0].tel}}
		</text>
		<u-gap height="20" bg-color="#e6dee2"></u-gap>
		<br>
		<text style="margin-left: 16%;font-size: 20px;">
			居住地：{{Data[0].location}}
		</text>
		<br>
		<view class="anniu">
			<u-button type="">编辑信息</u-button>
			<u-gap height="30" bg-color="#e6dee2"></u-gap>
			<u-button type="error"  @click="loginout">退出登陆</u-button>
		</view>
		
	</view>
</template>

<script setup>
	import {
		onMounted,
		ref
	} from "vue";
	import {
		onLoad
	} from '@dcloudio/uni-app';
	const Data = ref([]);
	
	const loginout = () => {
		try {
			uni.removeStorageSync('userInfo');
			// return islogin.value = false
			uni.switchTab({
				url: '/pages/userCenter/userCenter'
			});
			uni.reLaunch({
				url:"/pages/userCenter/userCenter"
			})
		} catch (err) {
			console.log(err)
		}
	}
	
	onLoad((option) => {
		
		console.log(option)
		uni.request({
			url: `http://localhost:3000/user/getFavoriteByUserId?userId=${option.id}`,
			method: "GET",
			success: function(res) {
				if (res.statusCode === 200) {
					// 处理返回的数据
					console.log(res.data);
					Data.value = res.data.data
				} else {
					// 处理请求成功但业务逻辑上的错误
					console.error('请求成功，但状态码不是200');
				}
			},
			fail: function(error) {
				// 处理请求失败的情况
				console.error('请求失败', error);
			}
		});
	});
</script>

<style>
	.anniu{
		margin-top: 68%;
	}
	.all {
		width: 90%;
		margin-left: 5%;
	}

	.all::before {
		z-index: -1;
		content: '';
		position: absolute;
		top: 0;
		left: 0;
		width: 100%;
		height: 10%;
		/* 假设上半部分占页面高度的一半 */
		background-color: #E60026;
	}

	.all::after {
		z-index: -1;
		content: '';
		position: absolute;
		top: 10%;
		/* 从上半部分的底部开始 */
		left: 0;
		width: 100%;
		height: 90%;
		/* 假设下半部分也占页面高度的一半 */
		background-color: #e6dee2;
	}
</style>