<template>
	<view class="wrap">
		<view class="container">
			<view class="image-container">
				<u-image :src="`http://localhost:3000/${artdata[0].artistAvatar}`" width="300rpx"
					height="300rpx"></u-image>
			</view>
			<view class="text-container">
				<view class="">
				</view>
				<text class="text-upper">
					{{artdata[0].artistName}}
				</text>
				<view class="text-lower">
					<u-button>关注</u-button>
				</view>
			</view>

		</view>
		<u-gap height="6" bg-color="white"></u-gap>
		<view class="gequ">
			<text style="font-size:large">
				TA的歌曲
			</text>
			<!-- 如果没有歌曲就暂时空 -->
			<u-gap height="300" bg-color="white" v-if="artdata[0].songs.length == 0"  ></u-gap>
			<u-empty text="" mode="search" v-if="artdata[0].songs.length == 0" margin-top="10vh" ></u-empty>
			<!-- 如果没有歌曲就暂时空 -->
			<u-gap height="6" bg-color="white"></u-gap>
			<u-row v-for="s in artdata[0].songs" gutter="16" @click="play(s.songId)">
				<u-gap height="6" bg-color="white"></u-gap>
				<u-gap height="2" bg-color="black"></u-gap>
				<u-gap height="6" bg-color="white"></u-gap>
				<u-col span="2">&nbsp;</u-col>
				<u-col span="4">
					<u-image :src="`http://localhost:3000/${s.songCover}`" width="100rpx" height="100rpx"></u-image>
				</u-col>
				<u-col span="6">
					<u-gap height="32" bg-color="white"></u-gap>
					{{s.songTitle}}</u-col>

			</u-row>
			<!-- 如果没有歌曲就暂时空 -->
			<u-gap height="2" bg-color="black" v-if="artdata[0].songs.length !== 0" ></u-gap>
			<u-gap height="6" bg-color="white" ></u-gap>
		</view>
	</view>
</template>

<script setup>
	import {
		ref,
	} from 'vue';
	import {
		onLoad
	} from '@dcloudio/uni-app';
	const play = (res) => {
		console.log(res)
		uni.navigateTo({
			url: "/pages/index/musicPlay?id=" + JSON.stringify(res)
		});
	}
	const artdata = ref([])
	onLoad((option) => {
		console.log(option.id)
		uni.request({
			method: 'GET',
			url: `http://localhost:3000/artist/getArtistByid?artistId=${option.id}`,
			success: (res) => {
				console.log(res.data);
				artdata.value = res.data.data;
				console.log(artdata.value)
			}
		})
	})
</script>

<style>
	.wrap {
		background-color: $u-bg-color;
		min-height: 100vh;
		margin-left: 3%;
		margin-right: 3%;
		margin-top: 3%;
	}

	.container {
		display: flex;
		/* 启用Flex布局 */
	}

	.image-container {
		margin-left: 6vw;
		flex: 0 1 200px;
		/* 不可伸缩，宽度固定为200px */
		margin-right: 20px;
		/* 图片和文字之间的间距 */
	}

	.text-container {
		display: flex;
		/* 启用Flex布局 */
		flex-direction: column;
		/* 子元素垂直排列 */
		justify-content: space-between;
		/* 子元素之间的空间平均分布 */
	}

	.text-upper {
		margin-top: 2vh;
		flex: 1;
		font-size: large;
	}

	.text-lower {
		flex: 1;
		/* 子元素可以伸缩以填充空间 */
	}
</style>