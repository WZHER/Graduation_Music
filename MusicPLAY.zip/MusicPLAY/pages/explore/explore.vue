<template>
	<view class="wrap">
		<u-gap height="12" bg-color="white"></u-gap>
		<u-subsection :list="list" v-model="current" style=""></u-subsection>
		<u-gap height="12" bg-color="white"></u-gap>

		<view class="all1" v-if="current === 0">
			<u-tr class="u-tr">
				<u-th class="u-th">排名</u-th>
				<u-th class="u-th">封面</u-th>
				<u-th class="u-th">歌曲名</u-th>
				<u-th class="u-th">歌手名</u-th>
			</u-tr>
			<u-gap height="2" bg-color="black"></u-gap>
			<view class="" v-for="(s,index) in songData.slice(8,18) " :key='index'>
				<u-gap height="6" bg-color="white"></u-gap>
				<u-row gutter="16" @click="play(s.songId)">
					<u-col span="2">
						<u-gap height="32" bg-color="white"></u-gap>
						<text style="display: flex; align-items: center; justify-content: center;">
							<u-gap height="32" bg-color="white"></u-gap>
							{{index+1}}
						</text>
					</u-col>
					<u-col span="3">
						<u-image :src="`http://localhost:3000/${s.songCover}`" width="100rpx" height="100rpx"></u-image>
					</u-col>
					<u-col span="4">
						<u-gap height="32" bg-color="white"></u-gap>
						{{s.songTitle}}
					</u-col>
					<u-col span="3">
						<u-gap height="32" bg-color="white"></u-gap>
						{{s.songAuthor}}
					</u-col>
				</u-row>
				<u-gap height="6" bg-color="white"></u-gap>
				<u-gap height="2" bg-color="black"></u-gap>
				<u-gap height="6" bg-color="white"></u-gap>
			</view>
		</view>

		<view class="all2" v-if="current === 1">
			<view class="heart-container" @click="suiji()">
				<view class="circle">
				</view>
			</view>
		</view>

		<view class="all3" v-if="current === 2">
			<view class="">
				<u-grid :col="3">
					<u-grid-item v-for="(a,index) in artistData" :key='index' @click="geshoudetail(a.artistId)">
						<u-image :src="`http://localhost:3000/${a.artistAvatar}`" width="100rpx"
							height="100rpx"></u-image>
						<view class="grid-text">{{a.artistName}}</view>
					</u-grid-item>
				</u-grid>
			</view>
		</view>


	</view>

</template>

<script setup>
	import {
		ref,
		reactive
	} from 'vue';
	import {
		onLoad
	} from '@dcloudio/uni-app';

	const suiji = () => {
		// const randomNum = ref(0)
		const randomNum = ref(Math.floor(Math.random() * 29) + 5);
		// 生成一个随机数,然后跳转到音乐播放页面
		uni.navigateTo({
			url: "/pages/index/musicPlay?id=" + JSON.stringify(randomNum.value)
		});
	}

	const geshoudetail = (res) => {
		console.log(res)
		uni.navigateTo({
			url: "/pages/explore/artist/artist?id=" + JSON.stringify(res)
		});
	}

	const toggleShow = () => {
		show.value = !show.value;
	};

	const play = (res) => {
		console.log(res)
		uni.navigateTo({
			url: "/pages/index/musicPlay?id=" + JSON.stringify(res)
		});
	}
	const keyword = ref(""); // 初始化为空字符串，允许用户输入

	let current = ref(1);
	const list = reactive([{
			name: '歌曲榜',
		},
		{
			name: '心情',
		},
		{
			name: '歌手',
		}
	]);

	const songData = ref([]);
	const artistData = ref([]);
	onLoad(async () => {
		try {
			// 使用 Promise.all 来并行执行多个请求
			const [songsResponse, artistsResponse] = await Promise.all([
				getSongs(),
				getArtists()
			]);

			// 假设返回的数据格式为 { data: [] }
			songData.value = songsResponse.data;
			artistData.value = artistsResponse.data;
		} catch (error) {
			console.error('请求失败:', error);
		}
	});

	// 定义请求歌曲数据的函数
	async function getSongs() {
		const res = await uni.request({
			url: "http://localhost:3000/song/getSongs",
			method: "GET"
		});

		if (res.statusCode === 200) {
			return res.data;
		} else {
			throw new Error('获取歌曲数据失败');
		}
	}

	// 定义请求艺术家数据的函数
	async function getArtists() {
		const res = await uni.request({
			url: "http://localhost:3000/artist/getArtists",
			method: "GET",

		});
		console.log(res)
		if (res.statusCode === 200) {
			return res.data;
		} else {
			throw new Error('获取艺术家数据失败');
		}
	}
</script>

<style>
	.wrap {
		background-color: $u-bg-color;
		min-height: 100vh;
		margin-left: 3%;
		margin-right: 3%;
	}

	.content {
		width: 100%;
		height: 85vh;
		box-sizing: border-box;
	}

	.all2 {

		display: flex;
		justify-content: center;
		align-items: center;
		height: 85vh;
		/* 或者设置为具体的高度 */

	}

	/* HEART LOADER */
	/* 定义跳动动画的关键帧 */
	@keyframes heartbeat {

		0%,
		100% {
			transform: scale(1);
		}

		25% {
			transform: scale(1.1);
		}

		50% {
			transform: scale(1);
		}

		75% {
			transform: scale(1.1);
		}
	}

	/* 心形容器 */
	.heart-container {
		position: relative;
		width: 100px;
		height: 100px;
		animation: heartbeat 1s infinite;
	}

	/* 心形容器内的正方形 */
	.heart-container::after {
		content: '';
		position: absolute;
		top: 35px;
		left: 50px;
		width: 58px;
		height: 58px;
		background: red;
		transform: rotate(-45deg);
		transform-origin: bottom left;
	}

	/* 左上角的圆 */
	.heart-container::before {
		content: '';
		position: absolute;
		top: 0;
		left: 0;
		width: 60px;
		height: 60px;
		background: red;
		border-radius: 50%;
	}

	/* 右下角的圆 */
	.heart-container .circle {
		position: absolute;
		top: 0;
		right: 0;
		width: 60px;
		height: 60px;
		background: red;
		border-radius: 50%;
	}
</style>