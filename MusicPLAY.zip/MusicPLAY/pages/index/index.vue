<template>
	<view class="wrap">
		<u-gap height="12" bg-color="white"></u-gap>
		<u-search placeholder="请输入关键字" :show-action="true" height="70" @clear="clear" search-icon-color="black"
			v-model="keyword" @custom="search" @search="search">
		</u-search>
		<u-gap height="12" bg-color="white"></u-gap>
		<!-- 搜索	 -->
		<!-- 轮播图 -->
		<view>
			<u-swiper :list="list" mode="rect" :circular="true" height="140rpx" class="swiper"></u-swiper>
		</view>
		<u-gap height="12" bg-color="white"></u-gap>

		<view class="">

		</view>

		<text style="font-size:50rpx; color\:#E60026;">歌单推荐</text>
		<u-gap height="12" bg-color="white"></u-gap>
		<!-- 歌单推荐页面 -->
		<view>
			<u-row gutter="16">
				<u-col span="4" v-for="(gd,index) in collectData.slice(0, 6)">
					<img :src="`http://localhost:3000/${collectData[index].cover}`" @click="collectDetail(gd.collectId)"
						style="width: 82px; height: 82px;">
					<br><span>{{collectData[index].collectName}}</span>
				</u-col>
				<br>
			</u-row>
		</view>
		<text style="font-size:50rpx; color\:#E60026;">歌曲推荐</text>
		<u-gap height="12" bg-color="white"></u-gap>
		<view class="controller">
			<image :src="'http://localhost:3000/'+newData.songCover" mode=""></image>
			<view class="">
				{{newData.songTitle}}
			</view>
		</view>
		<view style="height: 300px;">
			<u-row gutter="16">
				<u-col span="4" v-for="(gq, index) in songData.slice(0, 6)">
					<img :src="`http://localhost:3000/${songData[index].songCover}`" @click="songDetail(gq.songId)"
						style="width: 82px; height: 82px;">
					<br><span>{{songData[index].songTitle}}</span>
				</u-col>
				<br>
			</u-row>
		</view>
	</view>
</template>

<script setup>
	import {
		onMounted,
		ref
	} from "vue";
	import {
		onLoad
	} from '@dcloudio/uni-app';
	import {
		useStore
	} from 'vuex'
	const keyword = ref()
	const store = useStore();
	const newData = ref({})
	var list = [{
			image: 'https://p1.music.126.net/muoUe5QbSkji0j6gNFTUHQ==/109951169300736996.jpg?imageView&quality=89',
			title: '昨夜星辰昨夜风，画楼西畔桂堂东。'
		},
		{
			image: 'https://p1.music.126.net/Q7voav0sij-Jb9Lhg7H6bg==/109951169300704352.jpg?imageView&quality=89',
			title: '身无彩凤双飞翼，心有灵犀一点通。'
		},
		{
			image: 'https://p1.music.126.net/NEl-4VVzbndiyYYOkxOjGQ==/109951169300792080.jpg?imageView&quality=89',
			title: '山外青山楼外楼，西湖歌舞几时休。'
		}
	];

	onMounted(() => {
		store.watch((state) => {
			newData.value = state.PlayList
		})
	})

	const search = () => {
		uni.navigateTo({
			url: `/pages/index/search?keyword=${encodeURIComponent(keyword.value)}`
		})
		keyword.value = ''
	}

	const collectDetail = (res) => {
		console.log(res)
		uni.navigateTo({
			url: "/pages/index/collectDetail?id=" + JSON.stringify(res)
		});
	}
	const id = ref()
	const songDetail = (res) => {
		uni.navigateTo({
			url: "/pages/index/musicPlay?id=" + JSON.stringify(res)
		});
	}
	const collectData = ref([]);
	const songData = ref([]);
	onLoad(() => {
		getAllCollectdata();
		getAllSongdata();
	})
	//获取推荐歌单
	const getAllCollectdata = () => {
		uni.request({
			url: "http://localhost:3000/collect/getCollects",
			method: "GET",
			success: function(res) {
				console.log(res.data);
				collectData.value = res.data.data;
				console.log(collectData)
			}
		})
	}
	//获取推荐歌曲
	const getAllSongdata = () => {
		uni.request({
			url: "http://localhost:3000/song/getsongs",
			method: "GET",
			success: function(res) {
				console.log(res.data);
				songData.value = res.data.data;
				console.log(songData)
			}
		})
	}
</script>

<style>
	.wrap {
		background-color: $u-bg-color;
		min-height: 100vh;
		margin-left: 3%;
		margin-right: 3%;
	}

	.swiper {
		margin-top: 2%;
	}

	.logo {
		height: 200rpx;
		width: 200rpx;
		margin-top: 200rpx;
		margin-left: auto;
		margin-right: auto;
		margin-bottom: 50rpx;
	}

	.title {
		font-size: 36rpx;
		color: #8f8f94;
	}

	.controller {
		position: fixed;
		background-color: red;
		width: 100%;
		height: 50px;
		left: 0;
		bottom: 0px;
		display: flex;
		align-items: center;
		justify-content: space-between;
	}

	.controller image {
		width: 100rpx;
		height: 100rpx;
		border-radius: 50%;
	}
</style>