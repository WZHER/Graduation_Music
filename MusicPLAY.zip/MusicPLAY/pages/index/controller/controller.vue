<template>
	<view class="content">
		<image :src="data.img" mode=""></image>
		<view class="">
			{{data.name}}
		</view>
		<view class="">

		</view>
	</view>
</template>

<script>
	import {
		useStore
	} from 'vuex'
	export default {
		data() {
			return {
				store: useStore(s)
			}
		},
		mounted() {
			console.log(this.store.state.PlayList);
		},
		methods: {

		}
	}
</script>


<style scoped>
	.content {
		width: 100%;
		height: 20px;
		position: absolute;
		display: flex;
		align-items: center;
		justify-content: space-between;
		background-color: red;
	}
</style>