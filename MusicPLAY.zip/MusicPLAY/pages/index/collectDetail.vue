<template>
	<view class="wrap" v-if="tableData && tableData.length > 0">
		<view>
			<u-row guttrt="16">
				<u-col span="4">
					<img :src="`http://localhost:3000/${tableData[0].cover}`"
						style="width: 160rpx; height: 160rpx; margin-left: 10px; margin-top: 10px;" alt="">
				</u-col>
				<u-col span="8">
					<text style="font-size: 30px;">
						{{tableData[0].collectName}}
					</text>
					<br>
					<text style="font-size: 20px;">
						{{tableData[0].synopsis}}
					</text>
				</u-col>
			</u-row>



		</view>
		<u-gap height="16" bg-color="white"></u-gap>
		<u-gap height="1" bg-color="red"></u-gap>
		<u-gap height="16" bg-color="white"></u-gap>
		<view>
			<u-row guttrt="16">
				<u-col span="4"><text style="font-weight: bold; font-size: 17px;">歌曲标题</text></u-col>
				<u-col span="4"><text style="font-weight: bold; font-size: 17px;">歌手</text></u-col>
				<u-col span="4"><text style="font-weight: bold; font-size: 17px;">操作</text></u-col>
			</u-row>
			<u-gap height="20" bg-color="white"></u-gap>
			<u-row gutter="16" v-for="s in songData">
				
				<u-col span="4">
				{{s.songTitle}}
				</u-col>
				<u-col span="4">{{s.songAuthor}}</u-col>
				<u-col span="4">
					<u-row gutter="16">
						<u-gap height="10" bg-color="white"></u-gap>
						<u-col span="4">
							<img src=".././static/播放.png" @click="play(s.songId)" style="width: 50rpx; height: 50rpx;">
						</u-col>
						<u-col span="2">
							&nbsp
						</u-col>
						<u-col span="4">
							<img src=".././static/like.png" style="width: 50rpx; height: 50rpx;" alt="">
						</u-col>
					</u-row>
				</u-col>
			
			</u-row>
		</view>

	</view>

</template>

<script setup>
	import {
		ref
	} from "vue";
	import {
		onLoad
	} from '@dcloudio/uni-app';
	const play = (res) => {
		console.log(res)
		uni.navigateTo({
			url: "/pages/index/musicPlay?id=" + JSON.stringify(res)
		});
	}
	const tableData = ref([]);
	const songData = ref([]);
	onLoad((option) => {
		uni.request({
			url: `http://localhost:3000/collect/getCollectsByid?collectId=${option.id}`,
			method: "GET",
			success: function(res) {
				tableData.value = res.data.data;
				songData.value = res.data.data[0].songs;
				uni.request({
					url: `http://localhost:3000/user/getUsersById?userId=${res.data.data[0].userId}`,
					method: "GET",
					success: function(res) {
						console.log(res.data)
					}
				})
			}
		})

	})
</script>

<style>
	.wrap {
		background-color: $u-bg-color;
		min-height: 100vh;
		margin-left: 3%;
		margin-right: 3%;
	}
</style>