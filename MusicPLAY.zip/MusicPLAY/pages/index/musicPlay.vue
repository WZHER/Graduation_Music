<template>
	<view class="play-page" :style="bgStyle">
		<view class="bg"></view>
		<!-- 拔条 -->
		<view class="strip-box" v-if="contro == 1" :class="playState ? 'active' : ''">
			<image class="img"
				src="https://s3.music.126.net/mobile-new/img/needle-ip6.png?be4ebbeb6befadfcae75ce174e7db862=" mode="">
			</image>
		</view>
		<view class="content">
			<!-- 转盘图片 -->
			<view class="play-poster" v-if="contro == 1" @click="contro = 2">
				<view class="poster-box">
					<image class="img" :src="'http://localhost:3000/'+curSongItem.songCover" mode="widthFix"></image>
				</view>
			</view>
			<view class="order" v-else @click="contro = 1">
				<view id="order" class="other-big" :style="{top:top+'px'}">
					<view class="other" v-for="(item,index) in arr" :key="index" style="text-align: center;"
						:style="{'color':index==nowlyrie?'red':'black' , 'transform':'translateY('+ height + 'px)'}">
						{{item.words}}
						<span style="display: none;">
							{{index}}--{{nowlyrie}}
						</span>
					</view>
				</view>
			</view>
			<view class="bot">
				<view class="slider-bar flex-box">
					<view class="time start">
						{{curPlayTimeNum}}
					</view>
					<slider class="line flex-item" :value="nowtimes" min="0" :max="playTime" block-size="15"
						@change="sliderChange" backgroundColor="rgba(255,255,255,.5)"
						activeColor="rgba(255,255,255,.5)" />
					<view class="time end">
						{{playTimeNum}}
					</view>
				</view>
				<!-- 下排的图标 -->
				<view class="btn-groups flex-box">
					<!-- 播放模式 -->
					<view class="flex-item" @click="setPlayModel()">
						<!-- 列表循环 -->
						<view v-if="playModel==0" class="iconfont">
							<img src="../../static/随机播放.png" style="width: 80rpx; height:80rpx;">
						</view>
					</view>
					<!-- 上一曲 -->
					<view class="flex-item" @click="prevPlay()">
						<view class="iconfont">
							<image src="../../static/上一曲.png" mode="aspectFit" @click="Play"
								style="width: 80rpx; height:80rpx;">
							</image>
						</view>
					</view>
					<!-- 播放/暂停 -->
					<view class="play-btn" @click="play()">
						<view v-if="!playState" class="iconfont">
							<image src="../../static/播放.png" mode="aspectFit" @click="Play"
								style="width: 80rpx; height:80rpx;">
							</image>
						</view>
						<view v-if="playState" class="iconfont">
							<image src="../../static/暂停.png" mode="aspectFit" @click="Play"
								style="width: 80rpx; height:80rpx;">
							</image>
						</view>
					</view>
					<!-- 下一曲 -->
					<view class="flex-item" @click="nextPlay()">
						<view class="iconfont">
							<img src="../../static/下一曲.png" style="width: 80rpx; height:80rpx;">
						</view>
					</view>
					<!-- 菜单 -->
					<view class="flex-item iconfont" @click="like()">
						<img src="../../static/like.png" style="width: 70rpx; height:70rpx;">
					</view>
				</view>
			</view>

		</view>
	</view>
</template>
<script>
	let innerAudioContext = null

	import {

		ref
	} from "vue";
	import {
		useStore
	} from 'vuex'
	export default {
		data() {
			return {
				  userid: null,
				id: null,
				playState: 0, //播放状态  1播放  0暂停
				curPlayIndex: 0, //当前播放索引
				curPlayTime: 0, //当前播放时间
				curSongItem: {}, //当前播放对象
				playTime: 0, //音乐播放时长
				audioList: [], //音乐列表
				playModel: 0, //播放模式 0-列表循环 1-随机 2-单曲
				contro: 1,
				arr: [],
				top: 0,
				height: 0,
				result: 0,
				time: null,
				nowtimes: 0,
				nowlyrie: 0,
				store: useStore()
			}
		},
		computed: {
			bgStyle() {
				return 'background-image:url(' + 'http://localhost:3000/' + this.curSongItem.songCover || '' + ')';
			},
			//开始时间00：00
			// curPlayTimeNum() {
			// 	return this.$pubFn.formatTime(this.curPlayTime);
			// },
			// //总时长
			// playTimeNum() {
			// 	return this.$pubFn.formatTime(this.playTime);
			// }
		},
		mounted() {
			this.curPlayIndex = 0;
			this.playInit();
			//得到音乐列表
			// this.audioList = this.playList;
			console.log(this.store);
		},
		methods: {

			// 	//初始化
			playInit() {
				this.curPlayTime = 0;

				//获取音乐文件
				setTimeout(() => {
					this.getData();
				}, 100)
			},
			// 	//获取音乐url, 详情  同时调用多个接口
			async getData() {
				if (this.audioList) {
					this.setAudio();
					this.play()
				} else {
					uni.showToast({
						title: 'url不存在！'
					})
				}

			},
			// 设置播放的文件
			setAudio() {
				//若存在之前的实例则取消
				if (innerAudioContext) {
					// #ifdef H5
					innerAudioContext.destroy();
					// #endif
					innerAudioContext = "";
				}
				//创建实例 H5中
				// #ifdef H5
				innerAudioContext = uni.createInnerAudioContext();
				// #endif

				//创建实例 非H5中
				// #ifndef H5
				innerAudioContext = uni.getBackgroundAudioManager();
				innerAudioContext.title = this.curSongItem.songTitle;
				innerAudioContext.singer = this.curSongItem.singer;
				innerAudioContext.coverImgUrl = this.curSongItem.songCover;
				// #endif

				innerAudioContext.src = "http://localhost:3000/" + this.curSongItem.filePath;
				innerAudioContext.autoplay = true;
				//获取音乐时长 可能读的时候innerAudioContext还没有准备好
				let timer = setInterval(() => {
					console.log("时长：", innerAudioContext.duration);
					// innerAudioContext.duration  NaN
					this.playTime = Math.floor(innerAudioContext.duration || 0);
					if (this.playTime) {
						clearInterval(timer);
					}
				}, 100);
				//监听事件
				innerAudioContext.onPlay(() => {
					this.playState = 1;
					this.store.state.AudioFlag = 1
				})
				innerAudioContext.onPause(() => {
					this.playState = 0;
					this.store.state.AudioFlag = 0
				})
				innerAudioContext.onEnded(() => {
					console.log("音乐结束，跳转一下首。")
					// this.nextPlay();
				})
				//监听进度条
				innerAudioContext.onTimeUpdate(() => {
					//得到当前播放时间
					this.curPlayTime = Math.floor(this.curPlayTime.currentTime);
				})
				let that = this;
				let arrs = []
				// 歌词
				uni.request({
					url: `http://localhost:3000/${this.curSongItem.lyrics}`,
					method: "GET",
					success: function(res) {
						console.log(res);
						let lrc = [];
						lrc = res.data.split("\n")
						lrc.forEach((val, i) => {
							var words = val.split("]") //分割歌词
							var time = words[0].slice(1, 10) //选择从下标为1到下标为10的字符串
							arrs.push({
								// 歌词时间转换
								time: ((time.slice(0, 2) - 0) * 60) + (time.slice(3, 5) - 0) +
									((time.slice(6, 9) - 0) / 1000), //歌词时间转换为秒
								words: words[1] ? words[1] : ""
							})
						})
						console.log(arrs);
						that.arr = arrs.filter(item => item.words.trim() != '')
						console.log(that.arr);

					}
				})
			},


			//播放暂停
			play() {
				let that = this;
				if (this.playState === 1) { //播放
					//暂停
					innerAudioContext.pause();
					clearInterval(that.time)
				}
				if (this.playState === 0) { //暂停
					innerAudioContext.play();
					that.time = setInterval(() => {
						that.playState = that.store.state.AudioFlag
						that.nowtimes = innerAudioContext.currentTime
						that.result = innerAudioContext.currentTime
						for (var i = 0; i < that.arr.length; i++) {
							if (that.result <= that.arr[i].time) {
								var newi = i - 1;
								that.nowlyrie = newi;
								that.top = (newi * -20);
								var heigh = 250 - newi * 20
								that.height = heigh
								break;
							}
						}

						uni.createSelectorQuery().select("#order").scrollOffset(function(rect) {
							console.log(rect);
							uni.pageScrollTo({
								scrollTop: that.top,
								duration: 300
							})
						})
					}, 1000)
				}
			},
			like() {
				uni.request({
					url: "http://localhost:3000/favourite/add",
					method: 'POST',
					data: {
						userId: 1, // 替换为实际的用户ID
						songId: this.id // 替换为实际的歌曲ID
					},
					success: function(response) {
						// 处理成功的响应
						console.log(response);
					},
					fail: function(error) {
						// 处理失败的响应
						console.error(error);
					}
				})
			},

			prevPlay() {
				// const randomNum = ref(0
				// 生成一个随机数,然后跳转到音乐播放页面
				uni.reLaunch({
					url: "/pages/index/musicPlay?id=" + JSON.stringify(this.id - 1)
				});
			},
			nextPlay() {
				// const randomNum = ref(0
				const id = Number(this.id);
				uni.reLaunch({
					url: "/pages/index/musicPlay?id=" + JSON.stringify(id + 1)
				});
			},
			// 拖拽进度条
			sliderChange(e) {
				this.curPlayTime = e.detail.value;
				innerAudioContext.seek(this.curPlayTime);
			},

			//返回
			goBack() {
				uni.navigateBack();
			}
		},
		onLoad(option) {
			let that = this
			this.id = option.id;
			
			uni.request({
				url: `http://localhost:3000/song/getSongsByPage?id=${option.id}`,
				method: "GET",
				success: function(res) {
					that.curSongItem = res.data.data;
					that.store.state.PlayList = that.curSongItem
				}
			}),
			
			uni.getStorage({
			  key: "userInfo",
			  success: (res) => {
			    console.log(res.data.user);
			    userData.value = res.data.user; // 假设 userData 是一个 ref，用于存储用户数据
			    if (res.data.user && res.data.user.userId) {
			      this.userid = userData.userId; // 确保 res.data.user 包含 userId 属性
			    } else {
			      console.error('User data does not contain userId');
			    }
			  },
			  fail: (err) => {
			    console.error('Failed to get storage', err);
			  }
			});
		
		}
	}
</script>
<style lang="scss" scoped>
	.bg {
		position: fixed;
		z-index: 0;
		right: 0;
		left: 0;
		height: 100%;
		width: 100%;
		filter: blur(40rpx);
		background: inherit;
		z-index: -1;
		transform: scale(1.5);
	}

	.play-page {
		position: fixed;
		right: 0;
		left: 0;
		width: 100%;
		height: 100%;
		background-position: center center;
		background-repeat: no-repeat;
		background-size: cover;
	}

	.slider-bar {
		color: rgba(255, 255, 255, .6);
		padding: 20rpx 0;
		justify-content: space-between;


	}

	.line {
		margin: 0;
		border-radius: 2rpx;
		background-color: red;
	}

	.time {
		height: 36rpx;
		width: 80rpx;
		margin-right: 10rpx;
		font-size: 36rpx;
		line-height: 76rpx;
		transform: scale(0.5) translateY(-50%);
	}

	.strip-box {
		position: absolute;
		width: 100%;
		top: 142rpx;
		height: 329rpx;
		z-index: 100;
		transform: rotate(-30deg);
		transform-origin: center 0;
		transition: transform 0.3s;
	}

	.strip-box:before {
		position: absolute;
		content: "";
		top: -20rpx;
		left: 350rpx;
		width: 48rpx;
		height: 48rpx;
		border-radius: 48rpx;
		background: #fff;
		z-index: 100;
	}

	.strip-box.active {
		transform: rotate(0deg);
	}

	.strip-box .img {
		width: 220rpx;
		height: 330rpx;
		margin-left: 340rpx;
	}

	.play-poster {
		margin: 310rpx auto 0;
	}

	.play-poster .poster-box {
		display: flex;
		width: 616rpx;
		height: 616rpx;
		margin: 0 auto;
		background: url(https://s3.music.126.net/mobile-new/img/disc-ip6.png?69796123ad7cfe95781ea38aac8f2d48=) center center no-repeat;
		background-size: 100%;
		align-items: center;
		justify-content: center;
		animation: circling 20s linear infinite;
	}

	.play-poster .poster-box.pause {
		animation-play-state: paused;
	}

	.play-poster .img {
		display: block;
		margin: 0 auto;
		width: 382rpx;
		height: 382rpx;
		border: solid 16rpx rgba(0, 0, 0, .15);
		border-radius: 50%;
	}

	@-webkit-keyframes circling {
		0% {
			transform: rotate(0);
		}

		100% {
			transform: rotate(1turn);
		}
	}

	.btn-groups {
		width: 100%;
		align-items: center;
		justify-content: space-between;
		display: flex;
	}

	.btn-groups {
		align-items: center;
		text-align: center;
		display: flex;
	}

	.btn-groups .iconfont {
		font-size: 40rpx;
	}

	.btn-groups .play-btn {
		position: relative;
		width: 120rpx;
		height: 120rpx;
		line-height: 120rpx;
	}

	.btn-groups .play-btn:before {
		position: absolute;
		content: "";
		width: 240rpx;
		height: 240rpx;
		border: 1px solid #fff;
		border-radius: 240rpx;
		transform: scale(0.5) translate(-100%, -50%);
		z-index: -1;
	}

	.tool-groups {
		margin-bottom: 20rpx;
		text-align: center;
	}

	.tool-groups .iconfont {
		font-size: 40rpx;
	}

	.title-bar {
		position: fixed;
		top: 0;
		width: 100%;
		height: 44px;
		margin-top: 20px;
		text-align: center;
		line-height: 44px;
		color: #fff;
		z-index: 100;
	}

	.title-bar .name {
		line-height: 50rpx;
		font-size: 28rpx;
	}

	.title-bar .author {
		line-height: 1;
		font-size: 24rpx;
		color: rgba(255, 255, 255, .8);
	}

	.title-bar .iconfont {
		width: 110rpx;
		font-size: 44rpx;
	}

	.content {
		position: fixed;
		z-index: 1;
		right: 0;
		left: 0;
		height: 100%;
		width: 100%;
		color: #FFFDEF;
	}

	.content .bot {
		position: fixed;
		bottom: 40rpx;
		left: 0;
		width: 100%;
		padding: 0 26rpx;
	}

	.album-list {
		position: absolute;
		bottom: 0;
		background: #fff;
		border-radius: 36rpx 36rpx 0 0;
		z-index: 100;
		transition: transform 0.3s;
		transform: translateY(100%);
	}

	.album-list.active {
		transform: translateY(0);
	}

	.album-list .list {
		height: 500rpx;
		overflow-y: scroll;
	}

	.btn-groups {
		align-items: center;
		text-align: center;
		display: flex;
	}

	.btn-groups .iconfont {
		font-size: 40rpx;
		display: flex;
		height: 100%;
		justify-content: center;
		align-items: center;
	}

	.btn-groups .play-btn {
		position: relative;
		width: 120rpx;
		height: 120rpx;
		line-height: 120rpx;
	}

	.btn-groups .play-btn:before {
		position: absolute;
		content: "";
		width: 240rpx;
		height: 240rpx;
		border: 1px solid #fff;
		border-radius: 240rpx;
		transform: scale(0.5) translate(-100%, -50%);
		z-index: -1;
	}

	.tool-groups {
		margin-bottom: 20rpx;
		text-align: center;
	}

	.tool-groups .iconfont {
		font-size: 40rpx;
	}

	.title-bar {
		position: fixed;
		top: 0;
		width: 100%;
		height: 44px;
		margin-top: 20px;
		text-align: center;
		line-height: 44px;
		color: #fff;
		z-index: 100;
	}

	.title-bar .name {
		line-height: 50rpx;
		font-size: 28rpx;
	}

	.title-bar .author {
		line-height: 1;
		font-size: 24rpx;
		color: rgba(255, 255, 255, .8);
	}

	.title-bar .iconfont {
		width: 110rpx;
		font-size: 44rpx;
	}

	.content {
		position: fixed;
		z-index: 1;
		right: 0;
		left: 0;
		height: 100%;
		width: 100%;
		color: #FFFDEF;
	}

	.content .bot {
		position: fixed;
		bottom: 40rpx;
		left: 0;
		width: 100%;
		padding: 0 26rpx;
	}

	.album-list {
		position: absolute;
		bottom: 0;
		background: #fff;
		border-radius: 36rpx 36rpx 0 0;
		z-index: 100;
		transition: transform 0.3s;
		transform: translateY(100%);
	}

	.album-list.active {
		transform: translateY(0);
	}

	.album-list .list {
		height: 500rpx;
		overflow-y: scroll;
	}

	.wrap {
		width: 80%;
	}

	.other-width {
		display: flex;

		margin-top: 10%;
	}

	.other {
		line-height: 2s0px;
	}

	.order {
		height: 700rpx;
		position: relative;
		overflow: scroll;
		display: flex;
		justify-content: center;
	}

	.other-big {
		position: absolute;

	}

	.other-big view {
		height: 40px;
	}
</style>